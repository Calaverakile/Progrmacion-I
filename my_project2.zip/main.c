#include <stdio.h>

char nombres[100][50];
int recursos[100];
int tiempos[100];
int demandas[100];
int tiemposDisponibles[100];
int recursosDisponibles[100];
int cantidad = 0;

void agregarProducto() {
    if (cantidad >= 100) {
        printf("No se pueden agregar más productos.\n");
        return;
    }

    printf("Nombre del producto: ");
    getchar(); // limpiar el buffer
    fgets(nombres[cantidad], 50, stdin);

    printf("Recursos necesarios: ");
    scanf("%d", &recursos[cantidad]);

    printf("Tiempo de fabricación: ");
    scanf("%d", &tiempos[cantidad]);

    printf("Demanda del producto: ");
    scanf("%d", &demandas[cantidad]);

    printf("Tiempo disponible: ");
    scanf("%d", &tiemposDisponibles[cantidad]);

    printf("Recursos disponibles: ");
    scanf("%d", &recursosDisponibles[cantidad]);

    cantidad++;
    printf("Producto agregado.\n");
}

void editarProducto() {
    int i;
    printf("Número del producto (1 a %d): ", cantidad);
    scanf("%d", &i);
    i--;

    if (i < 0 || i >= cantidad) {
        printf("Producto no válido.\n");
        return;
    }

    printf("Nuevo nombre: ");
    getchar();
    fgets(nombres[i], 50, stdin);

    printf("Nuevos recursos necesarios: ");
    scanf("%d", &recursos[i]);

    printf("Nuevo tiempo de fabricación: ");
    scanf("%d", &tiempos[i]);

    printf("Nueva demanda: ");
    scanf("%d", &demandas[i]);

    printf("Nuevo tiempo disponible: ");
    scanf("%d", &tiemposDisponibles[i]);

    printf("Nuevos recursos disponibles: ");
    scanf("%d", &recursosDisponibles[i]);

    printf("Producto actualizado.\n");
}

void verInventario() {
    int i;
    printf("\n--- Inventario ---\n");
    for (i = 0; i < cantidad; i++) {
        printf("%d) %sRecursos: %d, Tiempo: %d, Demanda: %d\n",
               i + 1, nombres[i], recursos[i], tiempos[i], demandas[i]);
    }
    if (cantidad == 0) {
        printf("No hay productos.\n");
    }
    printf("-------------------\n");
}

void calcularDemanda() {
    int i;
    printf("Número del producto (1 a %d): ", cantidad);
    scanf("%d", &i);
    i--;

    if (i < 0 || i >= cantidad) {
        printf("Producto no válido.\n");
        return;
    }

    int tiempoTotal = tiempos[i] * demandas[i];
    int recursosTotales = recursos[i] * demandas[i];

    printf("\n--- Demanda de %s", nombres[i]);
    printf("Tiempo total: %d\n", tiempoTotal);
    printf("Recursos totales: %d\n", recursosTotales);

    if (tiempoTotal <= tiemposDisponibles[i] &&
        recursosTotales <= recursosDisponibles[i]) {
        printf("✔ Producción posible.\n");
    } else {
        printf("✖ Producción insuficiente.\n");
    }
}

int main() {
    int opcion;

    do {
        printf("\n=== MENÚ ===\n");
        printf("1. Agregar producto\n");
        printf("2. Editar producto\n");
        printf("3. Ver inventario\n");
        printf("4. Calcular demanda\n");
        printf("0. Salir\n");
        printf("Opción: ");
        scanf("%d", &opcion);

        if (opcion == 1) agregarProducto();
        else if (opcion == 2) editarProducto();
        else if (opcion == 3) verInventario();
        else if (opcion == 4) calcularDemanda();
        else if (opcion == 0) printf("Saliendo...\n");
        else printf("Opción inválida.\n");

    } while (opcion != 0);

    return 0;
}
